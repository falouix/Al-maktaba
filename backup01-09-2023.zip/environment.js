const Environment = {
  //api_url: 'http://localhost/almaktaba_api/'
  //api_url: 'https://almaktaba.info/almaktaba_api/'
  api_url: 'https://www.apialmaktaba.inspira-jendouba.org/almaktaba_api/'
  //api_url :'https://www.apialmaktaba.inspira-jendouba.org/almaktaba_api/'

};
export default Environment;