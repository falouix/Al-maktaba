const express = require('express');
const app = express();
///
const fs = require('fs');

const options = {
    key: fs.readFileSync('/etc/ssl/private/ssl-cert-snakeoil.key'),
    cert: fs.readFileSync('/etc/ssl/certs/ssl-cert-snakeoil.pem')
};

//
const http = require('https');
const server = http.createServer(options, app);
const { Server } = require("socket.io");
const io = new Server(server, {
    cors: {
        origin: '*',
    },
});
// Enable CORS
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
    console.log('a user connected');
    // Define a chat message event handler
    socket.on('chat message', (msg) => {
        console.log(`Message: ${msg}`);

        // Broadcast the message to all connected clients
        io.emit('chat message', msg);
    });

    // Define a disconnection event handler
    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });

});

server.listen(5000, () => {
    console.log('listening on *:5000');
});
