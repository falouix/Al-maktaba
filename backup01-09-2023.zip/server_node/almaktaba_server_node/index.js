const express = require("express")
const app = express()
const cors = require("cors")
const http = require('http').Server(app);
const PORT = 5000
const socketIO = require('socket.io')(http, {
    cors: {
        origin: "http://localhost:3000"
    }
});
const io = socketIO;
app.use(cors())
let users = []

io.on('connection', (socket) => {
    socket.on("join-connected-list", data => {
        console.log('a user connected', data.userId);
        users[data.userId] = { userId: data.userId, username: data.userName, roomId: socket.id };
        console.log(users)
        io.emit('user-list', Object.values(users));
    })
    // add new user to user list
    // emit user list to all clients
    socket.on('disconnect', () => {
        console.log('user disconnected', socket.id);
        let user;
        users.find((item) => {
            if (item != undefined && item.roomId == socket.id) {
                user = item
            }
        })
        // remove user from user list
        if (user != undefined) {
            delete users[user.userId];
        }
        console.log("users", users)
        // emit user list to all clients
        io.emit('user-list', Object.values(users));
    });

    /*socket.on('join-room', ({ roomId }) => {
        // update user's room ID
        users[socket.id].roomId = roomId;

        // emit user list to all clients
        io.emit('user-list', Object.values(users));

        socket.join(roomId);
    });*/

    /*socket.on('leave-room', ({ roomId }) => {
        // update user's room ID
        users[socket.id].roomId = '';

        // emit user list to all clients
        io.emit('user-list', Object.values(users));

        socket.leave(roomId);
    });*/

    socket.on('private-message', (data) => {
        console.log('private-message:', data);
        let user;
        let userReply;
        users.find((item) => {
            if (item != undefined && item.userId == data.userId) {
                user = item
            }
        })

        users.find((item) => {
            if (item != undefined && item.roomId == data.roomId) {
                userReply = item
            }
        })
        console.log(user)
        //if (user != undefined && userReply != undefined) {
        io.to(socket.id).emit('private-message', { roomId: data.roomId, message: data.message, userId: userReply.userId, username: 'reply' });
        io.to(data.roomId).emit('private-message', { ...data, username: user.username });
        //}
    });

    socket.on('set-username', (username) => {
        // update user's username
        users[socket.id].username = username;

        // emit user list to all clients
        io.emit('user-list', Object.values(users));
    });
});


app.get("/api", (req, res) => {
    res.json({ message: "Hello" })
});


http.listen(PORT, () => {
    console.log(`Server listening on ${PORT}`);
});