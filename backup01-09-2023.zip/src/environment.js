const Environment = {
  //api_url: 'http://localhost/almaktaba_api/'
  api_url: 'https://www.apialmaktaba.inspira-jendouba.org/'

};
export default Environment;