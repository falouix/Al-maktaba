
import react , {useState } from 'react';
import { BsFacebook,BsLinkedin } from "react-icons/bs";
function FriendList(){
    return (
        <>
        <h1>friends</h1>
        </>
    )
}

export default FriendList;