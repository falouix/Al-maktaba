import './Navbar.css';
import main_logo from '../../assets/maktabalogo.png'
export default function Navbar_mobile() {
  return ( 
    <nav className="nav">
       <h1>mobile menu</h1>
    </nav>
  )
}
