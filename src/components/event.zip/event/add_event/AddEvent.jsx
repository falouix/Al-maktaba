import React , {useState } from 'react';
import axios from 'axios';
import ProfilePic from '../../../assets/dashboard_assets/ProfilePic.png';
import { BiShare } from "react-icons/bi";
import Modal from 'react-modal';

function AddEvent(){
  
    return(
        <>
        <div className='addnew_container'>
        <h1>Créer Un Évènement</h1>
        <label>Nom D'Événement</label>
        <input type="text"/>
        <label>Description</label>
        <textarea type="text" rows="6"/>
        <label>Choisir La Date de Votre Évènement</label>
        <input type="date"/>
        <button class="thm-btn margin_top_5"><span>Créer</span></button>

        </div>
        </>
    );
}

export default AddEvent;