
import react , {useState,useEffect } from 'react';
import axios from 'axios';
import SideBar from './SideBar';
import Navbar from '../navbar/Navbar';
import Club_item_Container from './club_item_container/club_item_Container';
import AddNew from '../status/addNew/AddNew';
import { BiSearchAlt } from "react-icons/bi";
import Modal from 'react-modal';
import Cover_banner from '../../assets/dashboard_assets/events_assets/Cover_banner.png'
import AddClub from './add_club/AddClub';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';

const customStyles = {
  content: {
    width: '400px',
    heigth :'100hv',
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    padding : '10px',
    background : '#ededed',
    borderRadius : '10px',
    border : '1px solid red'
  },
};

Modal.setAppElement('#root');
function Clubs() {

    const  openClubpage = (id)=>{
        console.log(id)
    }
    const [test,settest] = useState(0);
    const [allClubs,setAlllClubs] = useState([]);
function AllClubs (){
    axios.get(`http://localhost:8080/almaktaba_api/clubs.php?action=getallclubs`)
    .then(async res => {
        await setAlllClubs(res.data.clubs)
    })
}
let allClubsItems=allClubs.map(item=>{
    return (
        <button onClick={event=>{openClubpage(item.id_club)}} className="btn_open">
                <Club_item_Container data={item}/>
            </button>
    )
});
// search or something
const options = allClubs.map((option) => {
    console.log( option.name_club[0].toUpperCase())
    const firstLetter = option.name_club[0].toUpperCase();
    return {
      firstLetter: /[0-9]/.test(firstLetter) ? '0-9' : firstLetter,
      ...option,
    };
  });

    useEffect(() => {
        AllClubs();
        
      },[test]);
    let subtitle;
    const [modalIsOpen1, setIsOpen1] = useState(false);
    function openModal1() {
        console.log('open')
        setIsOpen1(true);
    }
    function afterOpenModal1() {
      // references are now sync'd and can be accessed.
      //subtitle.style.color = '#f00';
    }
    function closeModal1() {
        setIsOpen1(false);
    }
    
    const [modalIsOpen, setIsOpen] = useState(false);
    function openModal() {
        console.log('open')
      setIsOpen(true);
    }
    function afterOpenModal() {
      // references are now sync'd and can be accessed.
      //subtitle.style.color = '#f00';
    }
    function closeModal() {
      setIsOpen(false);
    }
    return(
        <>

         <Modal
          isOpen={modalIsOpen1}
          onAfterOpen={afterOpenModal1}
          onRequestClose={closeModal1}
          style={customStyles}
          contentLabel="Example Modal"
          appElement={document.getElementById('app')}
        >
          <AddClub settest={settest}/>
        </Modal>

        <Modal
          isOpen={modalIsOpen}
          onAfterOpen={afterOpenModal}
          onRequestClose={closeModal}
          style={customStyles}
          contentLabel="Example Modal"
          appElement={document.getElementById('app')}
        >
            <AddClub/>
        </Modal>
        <Navbar />
        <div className='Dashboard_container'>
            <div className='side_container'>
                <SideBar />
            </div>
            <div className='dashboard_main'>
                <div className='add_status_container'>
                    <h1 className='h1_main_page_events'>
                        Clubs
                        <button class="thm-btn margin_top_5" onClick={openModal1}>
                            <span>Ajouter club</span>
                        </button>
                    </h1>
                    
                    
                    <h3 className='h3_main_page_events'>recherche</h3>
                    <div class="h1_main_page_search_container">
                        <BiSearchAlt className='event_main_page_search_icon'/>
                        <input type="text" placeholder='recherche' />
                        <button class="thm-btn margin_top_5"><span>recherche</span></button>
                    </div>
                </div>
                <Autocomplete
      id="grouped-demo"
      options={options.sort((a, b) => -b.firstLetter.localeCompare(a.firstLetter))}
      groupBy={(option) => option.firstLetter}
      getOptionLabel={(option) => option.name_club}
      sx={{ width: 300 }}
      renderInput={(params) => <TextField {...params} label="With categories" />}
    />


                <hr width = "95%"/>
                <h3 className='h3_main_page_university'>Clubs liste</h3>
                <div className='events_container'>
                    {allClubsItems}
                </div>
                    <h5 className='voir_plus'>Voir plus</h5>
                <hr width = "95%"/>
            </div>
        </div>
        </>
    )
}
export default Clubs;