import react , {useState } from 'react';
import axios from 'axios';
import './StatusPublication.css';
import Modal from 'react-modal';
let subtitle;
const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  },
};
Modal.setAppElement('#root');
function SideBar() {
  const [modalIsOpen, setIsOpen] = useState(false);
  function openModal() {
    setIsOpen(true);
  }
  function afterOpenModal() {
    // references are now sync'd and can be accessed.
    subtitle.style.color = '#f00';
  }
  function closeModal() {
    setIsOpen(false);
  }
  return(
		<div class="Book-box margin_top_10">
       <Modal
        isOpen={modalIsOpen}
        onAfterOpen={afterOpenModal}
        onRequestClose={closeModal}
        style={customStyles}
        contentLabel="Example Modal"
        appElement={document.getElementById('app')}
      >
        <h1>comment</h1>
        <p>sdgdfhjhgdfhj,</p>
      </Modal>
        <p className="margin_0 status_text_p">
          Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
          Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
          when an unknown printer took a galley of type and scrambled it to make a type
           specimen
        </p>
      <div class="status_btn_container">
      <h4 className='h4_status'>Date</h4>
				<button class="thm-btn" onClick={openModal}><span>Comment</span></button>
			</div>
		</div>
  )
}

export default SideBar;